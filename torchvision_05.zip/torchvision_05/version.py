__version__ = '0.4.0a0'
git_version = 'Unknown'
from torchvision import _C
if hasattr(_C, 'CUDA_VERSION'):
    cuda = _C.CUDA_VERSION
